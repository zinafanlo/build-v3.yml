# NOVA Browser V3
A phone-first Android browser/downloader starter with a redesigned UI, visible download actions for common file links/media, voice controls, JavaScript and developer toggles.

The voice assistant uses Android SpeechRecognizer and TextToSpeech. Full open-ended AI conversation requires an AI backend/API; this build does not pretend to include one.
